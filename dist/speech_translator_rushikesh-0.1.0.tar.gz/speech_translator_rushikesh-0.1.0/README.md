# Speech Translator

Real-time microphone speech to English translator.

## Install
pip install speech-translator-cli

## Usage
speech-translator

List microphones:
speech-translator --list-mic

Use specific mic:
speech-translator --mic 1

